package com.example.attendoapp;

public class Students {
    private String studenId;
    private String studentName;
    private String register;

    public  Students(){

    }

    public Students(String studenId, String studentName, String register) {
        this.studenId = studenId;
        this.studentName = studentName;
        this.register = register;
    }

    public String getStudenId() {
        return studenId;
    }

    public String getStudentName() {
        return studentName;
    }

    public String getRegister() {
        return register;
    }
}