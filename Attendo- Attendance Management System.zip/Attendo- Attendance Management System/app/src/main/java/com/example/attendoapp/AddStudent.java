package com.example.attendoapp;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddStudent extends AppCompatActivity {
    private EditText studentName, register;
    private Button add;
    private Button delete;

//    private Button viewStudents;
    private FirebaseAuth firebaseAuth;

    private TextView btnvaluedatabase;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_student);
        firebaseAuth = FirebaseAuth.getInstance();
        btnvaluedatabase = findViewById(R.id.passedclassnamedatabase);

//        viewStudents=findViewById(R.id.viewstud);
        Intent classintent = getIntent();
        String classnamepassed = classintent.getStringExtra("Classname1");
        btnvaluedatabase.setText(classnamepassed);

        databaseReference = FirebaseDatabase.getInstance().getReference("students");


        studentName = (EditText) findViewById(R.id.studentNamedatabase);
        register = (EditText) findViewById(R.id.mcneeseiddatabase);
        add = (Button) findViewById(R.id.addStudentdatabase);
        delete = (Button) findViewById(R.id.deleteStudentdatabase);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addStudent();
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteStudent();
            }
        });
//        viewStudents.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                viewstudents();
//
//            }
//        });

    }

//    private void viewstudents() {
//        Intent m = new Intent(getApplicationContext(), ViewStudents.class);
//        startActivity(m);
//    }


    public void addStudent() {
        String studentNameValue = studentName.getText().toString();
        String mcneeseIdValue = register.getText().toString();
        if (!TextUtils.isEmpty(studentNameValue) && !TextUtils.isEmpty(mcneeseIdValue)) {
            String id = databaseReference.push().getKey();
            Students students = new Students(id, studentNameValue, mcneeseIdValue);
            // databaseReference.child(bttnName.getText().toString()).push().setValue(students);
            databaseReference.child(btnvaluedatabase.getText().toString()).child(register.getText().toString()).setValue(students);
            studentName.setText("");
            register.setText("");
            Toast.makeText(AddStudent.this, "Student Details Added", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(AddStudent.this, "Please Fill Fields", Toast.LENGTH_SHORT).show();
        }
    }

    public void deleteStudent() {
        String studentNameValue = studentName.getText().toString();
        String mcneeseIdValue = register.getText().toString();

        if (!TextUtils.isEmpty(studentNameValue) && !TextUtils.isEmpty(mcneeseIdValue)) {
            String id = databaseReference.push().getKey();
            Students students = new Students(id, studentNameValue, mcneeseIdValue);
            // databaseReference.child(bttnName.getText().toString()).push().setValue(students);
            databaseReference.child(btnvaluedatabase.getText().toString()).child(register.getText().toString()).removeValue();

            studentName.setText("");
            register.setText("");
            Toast.makeText(AddStudent.this, "Student Deleted", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(AddStudent.this, "Please Fill Fields", Toast.LENGTH_SHORT).show();
        }
    }


    //logout

    // logout below
    private void Logout() {
        firebaseAuth.signOut();
        finish();
        startActivity(new Intent(AddStudent.this, SecondActivity.class));
        Toast.makeText(AddStudent.this, "LOGOUT SUCCESSFUL", Toast.LENGTH_SHORT).show();

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.logoutMenu) {

            Logout();
        }

        return super.onOptionsItemSelected(item);


    }
}
