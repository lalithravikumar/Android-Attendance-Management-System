package com.example.attendoapp;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText classname;
    int request_code =1;
    Button register;
    Button LOGIN;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        register=findViewById(R.id.buttonRegister);
        LOGIN=findViewById(R.id.submitbutton);

        LOGIN.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                startActivity(new Intent(getApplicationContext(),SecondActivity.class));
                Toast.makeText(MainActivity.this, "moving to two", Toast.LENGTH_SHORT).show();
            }



        });



        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),FourthActivity.class));

            }
        });

        //classname = findViewById(R.id.editclassname);
    }




}
