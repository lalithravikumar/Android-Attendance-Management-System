package com.example.attendoapp;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class FifthActivity extends AppCompatActivity {
   private TextView btnvalue;
    int request_code =1;
    private Button viewStudents;

    private FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fifth);
        firebaseAuth = FirebaseAuth.getInstance();
        btnvalue = findViewById(R.id.passedclassname);
        viewStudents=findViewById(R.id.viewstud);

        Intent classintent = getIntent();
        String classnamepassed = classintent.getStringExtra("Classname");
        btnvalue.setText(classnamepassed);

        viewStudents.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                viewstudents();

            }
        });
    }

    private void viewstudents() {
        Intent m = new Intent(getApplicationContext(), ViewStudents.class);
        startActivity(m);
    }
    public  void addStudents (View view){
        //startActivity(new Intent(this,AddStudent.class));

        String TextClassname = btnvalue.getText().toString();
        // starting our intent
        Intent classintent = new Intent(this,AddStudent.class);
        classintent.putExtra("Classname1",TextClassname);
        startActivityForResult(classintent,request_code);
    }

    public  void takeAttendence(View view){
       // startActivity(new Intent(this,TakeAttendence.class));

        String TextClassname = btnvalue.getText().toString();
        // starting our intent
        Intent classintent = new Intent(this,TakeAttendence.class);
        classintent.putExtra("Classname1",TextClassname);
        startActivityForResult(classintent,request_code);
    }






    // logout below
    private void Logout()
    {
        firebaseAuth.signOut();
        finish();
        startActivity(new Intent(FifthActivity.this,SecondActivity.class));
        Toast.makeText(FifthActivity.this,"LOGOUT SUCCESSFUL", Toast.LENGTH_SHORT).show();

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.logoutMenu) {

            Logout();
        }
        return super.onOptionsItemSelected(item);
    }
}
